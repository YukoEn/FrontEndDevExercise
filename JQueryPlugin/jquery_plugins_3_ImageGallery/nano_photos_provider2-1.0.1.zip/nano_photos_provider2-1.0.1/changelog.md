nanoPhotosProvider2 - nanogallery2 plugin
===========

**Visit nanoPhotosProvider2 homepage for usage details: [https://github.com/nanostudio-org/nanoPhotosProvider2](https://github.com/nanostudio-org/nanoPhotosProvider2)**


ChangeLog 
------

v1.0.0
------
- possibility to define the maximum image size used for display (full resolution version will be available for download)  
- blurred image quality configurable  
- enhanced cache management
- enhanced security  
- tags on photos  
- metadata files: changed separator from ':' to '='  
- configuration file: change section name 'thumbnail' to 'thumbnails'  

v0.9.1
------
- fixed upper case typo in filename

v0.9.0
------

- initial release for nanogallery2 - http://nanogallery2.nanostudio.org/
- not comptaible with nanoGALLERY
